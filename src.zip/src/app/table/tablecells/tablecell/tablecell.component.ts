import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tablecell',
  templateUrl: './tablecell.component.html',
  styleUrls: ['./tablecell.component.css']
})
export class tablecellComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
