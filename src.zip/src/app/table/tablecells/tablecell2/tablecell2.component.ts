import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tablecell2',
  templateUrl: './tablecell2.component.html',
  styleUrls: ['./tablecell2.component.css']
})
export class tablecell2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
